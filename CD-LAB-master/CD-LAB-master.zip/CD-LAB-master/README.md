# CD-LAB
coursework of Compiler design lab CS301P.
Note: Lab 3 was never submitted because of a change in naming convention.

# How to Compile and Run
1. Go to the specific folder.
2. For the first 3 labs, run Makefile and input as follows: change fname and input file according to problem #:
~~~bash
make fname=prob1.l lexer
./lexer inp1
make clean
~~~
3. For rest of the labs,
~~~bash
make fname=prob1
./parser inp<number>
make clean
~~~
