switch(a+b) {
    case 0: {x=a+b;break;}
    default: {
        x=a-b;
    }
}