while(z--) {
    t = a+b;
}