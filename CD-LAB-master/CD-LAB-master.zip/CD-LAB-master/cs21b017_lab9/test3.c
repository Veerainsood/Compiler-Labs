while(a+b==c || !a || a+c > d && a-b < c) {
    t = a+b;
}