while(c+d && (a+b==c || !a || a+c > d && a-b < c)) {
    t = a+b;
    if(a+b==c || !a || a+c > d && a-b < c) {
        t = a+b;
    }
    else {
        t = a+b;
    }
    t = a+b;
}
// Path: cs21b017_lab9/test5.c
